﻿  <footer>
      <div class= "container">
          <div class = "row">
              <div class = "footer-col">
                  <h4>Company</h4>
                  <ul>
                      <li><a href="#">aboutUS</a></li>
                      <li><a href="#">our services</a></li>
                      <li><a href="#">privacy policy</a></li>
                      <li><a href="#">FAQ</a></li>
                  </ul>
              </div>
              <div class = "footer-col">
                  <h4>FollowUS</h4>
                  <ul>
                      <li><a href="#"><i class="fab fa-facebook-f">     facebook</i></a></li>
                      <li><a href="#"><i class="fab fa-instagram">      Instagram</i></a></li>
                      <li><a href="#"><i class="fab fa-twitter">        Twitter</i></a></li>
                      <li><a href="#"><i class="fab fa-linkedin-in">    LinkedIn</i></a></li>
                  </ul>
              </div>
              <div class = "footer-col">
                  <h4>About Us</h4>
                   <p>Welcome to Insurance Company, your trusted partner in providing comprehensive insurance solutions.</p>
              </div>
          </div>
          <div class="copyRight">
              <p>&copy; <?php echo(date("Y")) ?> Who cares</p>
          </div>
      </div>
</footer>